# ATLAS — The Knowledge Navigator (Frontend)

Navigate Knowledge. Discover Insights.

A React + Vite frontend for an enterprise, role-aware, multilingual knowledge
search platform over Confluence / Jira / SharePoint. Runs standalone on mock
data — no backend required to demo.

## Run it

```bash
npm install
npm run dev      # http://localhost:5173
```

Build for production: `npm run build` (output in `dist/`).

## Sign in (demo auth)

Any password works. The role is inferred from the username:

- username contains **`admin`** → Admin view (all tabs, all documents)
- anything else → Employee view (Search + Library only, employee-visible docs)

Swap this out in `src/context/AppContext.jsx → login()` for your real auth call.

## What's in each tab

| Tab | Who | Notes |
|-----|-----|-------|
| Search | Employee + Admin | AI summary + citations, results feed with ratings/reviews, voice search, text-to-speech |
| Overview | Admin only | Usage KPIs, query trend, language mix, top topics, knowledge gaps |
| Document Library | Employee + Admin | Employees see only employee-visible docs |
| Access Control | Admin only | Employee/Admin permission matrix |
| Integrations | Admin only | Source connector health |

## Key features

- **Light / dark theme** — light is default; toggle is top-right in the header. Persisted to `localStorage`.
- **Document display language** — English UI, but documents can be shown in EN / DE / ES / FR via the globe selector in the header. Falls back to the source language and flags machine-translated content. Persisted to `localStorage`.
- **Role-based visibility** — Admin-only documents never render for employees, in results, library, or citations.
- **Public announcement banner** — outage/maintenance notice on every page. Toggle via `announcement.active` in `src/data/mock.js`.
- **Voice search + text-to-speech** — uses the browser's SpeechRecognition and SpeechSynthesis APIs (best in Chrome). No backend needed.
- **Document detail** — click any result/row to open the doc with translated body, TTS, metadata (at the end), ratings, and comments.

## Project structure

```
src/
  context/AppContext.jsx     auth/role, theme, language (+ integration notes)
  data/mock.js               ALL placeholder content — replace with API responses
  components/                Header, Sidebar, Layout, DocumentModal, etc.
  pages/                     Login, Search, Overview, Library, AccessControl, Integrations
  index.css                  theme tokens (light + dark) and shared styles
```

## Integration checklist (frontend → backend)

1. `login()` → real auth endpoint returning `{ name, role, initials }`.
2. `data/mock.js` documents/summary → search API responses. Keep the shape:
   `title/snippet/body` as `{ [langCode]: string }`, plus `visibility`,
   `rating`, `reviews`, `sourceLang`, `comments`.
3. Send the selected `language` to your translation backend as the target locale.
4. Wire the comment `Post` action and the rating to your API.
5. Replace `public/atlas-mark.svg` with the real ATLAS logo (same filename, or
   update references in `Sidebar.jsx`, `Login.jsx`, `Search.jsx`, `index.html`).

The UI never assumes a source of truth beyond what the API returns — all
role/language gating is applied to whatever documents you pass in.
