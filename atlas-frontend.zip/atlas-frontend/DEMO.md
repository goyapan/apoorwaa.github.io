# ATLAS — Demo script (≈5 minutes)

Run `npm install && npm run dev`, open http://localhost:5173, and follow this.

## 1. Login (30s)
- Land on the split-screen login. Read the line: *"The atlas of everything Deutsche Bank knows."*
- Sign in as an **employee** first: username `rohit.sharma`, any password.

## 2. Search — the core (90s)
- The search bar is pre-filled with *"What's the process for requesting AWS RDS access?"* — hit Search.
- Point out the three moving parts, top to bottom:
  1. **AI Summary** with a **Listen** (text-to-speech) button and numbered **citations**.
  2. **Relevant documents** feed — each with **star rating + review count** and a comment count.
  3. The **source logos** (Confluence / Jira / SharePoint) under the bar.
- Click the **mic** to show voice search (Chrome only).
- Click any result → the **document opens**: translated body, Listen button,
  **metadata at the end**, and a **comments** box — type one and Post it.

## 3. Multilingual (45s)
- Top-right **globe** → switch to **Deutsch**.
- The AI summary and document text switch to German; results flag *"translated from…"*
  where the source language differs. (UI chrome stays English — European-centric by design.)

## 4. Theme (15s)
- Top-right **moon icon** → dark theme. Everything re-themes instantly. Default is light.

## 5. Role-based access (60s)
- Open the profile menu (**three dots**, top-right) → **Log out**.
- Sign back in as an **admin**: username `jennifer.admin`, any password.
- Now the sidebar shows **Overview, Access Control, Integrations** too.
- **Overview**: usage KPIs, query trend, language mix, knowledge gaps.
- **Access Control**: the Employee vs Admin permission matrix.
- Back in **Search / Library**, note the admin sees the **Admin-only** document
  (DB-IAM-2026-07) that the employee could not.

## 6. Announcement (15s)
- Point out the **maintenance banner** at the top of every page — this is how
  outages/maintenance are surfaced. Dismissible.

## Talking points for judges
- **Trust**: every answer is grounded in cited sources with a confidence score.
- **Governance**: role filtering is described as enforced at retrieval time, not just hidden in the UI.
- **European-first**: one English interface, documents readable in any of four languages.
- **Adoption**: familiar Google-style search + Chrome-style account menu = zero learning curve.
