import React from "react";
import { Routes, Route, Navigate } from "react-router-dom";
import { useApp } from "./context/AppContext.jsx";
import Layout from "./components/Layout.jsx";
import Login from "./pages/Login.jsx";
import Search from "./pages/Search.jsx";
import Overview from "./pages/Overview.jsx";
import Library from "./pages/Library.jsx";
import AccessControl from "./pages/AccessControl.jsx";
import Integrations from "./pages/Integrations.jsx";

export default function App() {
  const { user } = useApp();

  if (!user) return <Login />;

  const adminOnly = (el) => (user.role === "admin" ? el : <Navigate to="/search" replace />);

  return (
    <Routes>
      <Route path="/search" element={<Layout><Search /></Layout>} />
      <Route path="/library" element={<Layout><Library /></Layout>} />
      <Route path="/overview" element={<Layout>{adminOnly(<Overview />)}</Layout>} />
      <Route path="/access" element={<Layout>{adminOnly(<AccessControl />)}</Layout>} />
      <Route path="/integrations" element={<Layout>{adminOnly(<Integrations />)}</Layout>} />
      <Route path="*" element={<Navigate to="/search" replace />} />
    </Routes>
  );
}
