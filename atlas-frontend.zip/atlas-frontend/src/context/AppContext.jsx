import React, { createContext, useContext, useEffect, useState } from "react";

const AppContext = createContext(null);
export const useApp = () => useContext(AppContext);

/*
  NOTE FOR BACKEND INTEGRATION
  ----------------------------
  - `user` here is a mock. Replace `login()` with a real API call that
    returns { name, role, initials }. Role must be "employee" | "admin".
  - `theme` and `language` are persisted in localStorage; wire them to
    user preferences on the backend if you want them to follow the account.
  - `language` is the DOCUMENT DISPLAY language. The UI chrome stays English.
    Send it to the translation backend as the target locale.
*/

export function AppProvider({ children }) {
  const [user, setUser] = useState(null);

  const [theme, setThemeState] = useState(
    () => localStorage.getItem("atlas.theme") || "light"
  );
  const [language, setLanguageState] = useState(
    () => localStorage.getItem("atlas.lang") || "en"
  );

  useEffect(() => {
    document.documentElement.setAttribute("data-theme", theme);
    localStorage.setItem("atlas.theme", theme);
  }, [theme]);

  useEffect(() => {
    localStorage.setItem("atlas.lang", language);
  }, [language]);

  const setTheme = (t) => setThemeState(t);
  const toggleTheme = () => setThemeState((t) => (t === "light" ? "dark" : "light"));
  const setLanguage = (l) => setLanguageState(l);

  // Mock login: any credentials work. Username containing "admin" -> admin role.
  // Swap this out for your real auth endpoint.
  const login = (username) => {
    const role = /admin/i.test(username) ? "admin" : "employee";
    const clean = username.replace(/[^a-zA-Z ]/g, " ").trim() || "DB User";
    const parts = clean.split(/\s+/);
    const initials = (parts[0][0] + (parts[1]?.[0] || parts[0][1] || "")).toUpperCase();
    const name =
      parts.map((p) => p[0].toUpperCase() + p.slice(1)).join(" ") ||
      (role === "admin" ? "Admin User" : "Employee User");
    setUser({ name, role, initials });
  };

  const logout = () => setUser(null);

  return (
    <AppContext.Provider
      value={{
        user, login, logout,
        theme, setTheme, toggleTheme,
        language, setLanguage,
      }}
    >
      {children}
    </AppContext.Provider>
  );
}
