/* ================================================================
   Mock data for ATLAS. Everything here is placeholder content so the
   frontend runs standalone. Replace with API responses at integration.
================================================================ */

export const LANGUAGES = [
  { code: "en", label: "English", flag: "🇬🇧" },
  { code: "de", label: "Deutsch", flag: "🇩🇪" },
  { code: "es", label: "Español", flag: "🇪🇸" },
  { code: "fr", label: "Français", flag: "🇫🇷" },
];

export const langLabel = (code) =>
  LANGUAGES.find((l) => l.code === code)?.label || code;

/* Public announcement — set active:false to hide the banner. */
export const announcement = {
  active: true,
  level: "warning", // "warning" | "info" | "critical"
  message:
    "Scheduled maintenance on the SharePoint connector, 24 Jul 22:00–23:30 CET. Search results from SharePoint may be delayed.",
};

/* The AI summary shown above results, with translations for demo. */
export const aiSummary = {
  query: "What's the process for requesting AWS RDS access?",
  text: {
    en: "To request AWS RDS access, submit a request through the Cloud Access Portal and tag your line manager as approver. Standard read-only roles are provisioned within one business day. Elevated or write access additionally requires Compliance sign-off under standard DB-IAM-2026-07.",
    de: "Um AWS-RDS-Zugriff anzufordern, reichen Sie eine Anfrage über das Cloud Access Portal ein und benennen Sie Ihre Führungskraft als genehmigende Person. Standard-Lesezugriffe werden innerhalb eines Werktags bereitgestellt. Erweiterte Zugriffe erfordern zusätzlich eine Freigabe durch Compliance gemäß Standard DB-IAM-2026-07.",
    es: "Para solicitar acceso a AWS RDS, envíe una solicitud a través del Portal de Acceso a la Nube e indique a su responsable como aprobador. Los roles de solo lectura estándar se aprovisionan en un día hábil. El acceso elevado requiere además la aprobación de Compliance según la norma DB-IAM-2026-07.",
    fr: "Pour demander un accès AWS RDS, soumettez une demande via le portail d'accès au cloud et désignez votre responsable comme approbateur. Les rôles standard en lecture seule sont provisionnés sous un jour ouvré. Un accès élevé nécessite en plus la validation de la Conformité selon la norme DB-IAM-2026-07.",
  },
  citations: [
    { n: 1, title: "Cloud Access Policy v4", source: "Confluence" },
    { n: 2, title: "RDS Onboarding Checklist", source: "SharePoint" },
    { n: 3, title: "DB-IAM-2026-07", source: "SharePoint", visibility: "admin" },
  ],
  confidence: 94,
};

export const SOURCE_STYLE = {
  Confluence: { letter: "C", color: "#2684FF" },
  Jira: { letter: "J", color: "#0052CC" },
  SharePoint: { letter: "S", color: "#0E7A6B" },
};

/*
  Documents. `visibility` gates who sees them (employee|admin).
  `title` / `snippet` / `body` carry per-language strings for demo.
  Where a language is missing, the UI falls back to English and shows a
  "machine-translated" note (that's your translation backend's job live).
*/
export const documents = [
  {
    id: "doc-1",
    source: "Confluence",
    path: "IT Governance › Cloud Access",
    sourceLang: "en",
    visibility: "employee",
    rating: 4.6,
    reviews: 38,
    updated: "2026-07-21",
    title: {
      en: "Cloud Access Policy v4",
      de: "Cloud-Zugriffsrichtlinie v4",
      es: "Política de Acceso a la Nube v4",
      fr: "Politique d'accès au cloud v4",
    },
    snippet: {
      en: "All engineers requesting AWS RDS access must submit a request via the Cloud Access Portal, tagging their manager as approver. Standard read roles provision within one business day.",
      de: "Alle Ingenieure, die AWS-RDS-Zugriff anfordern, müssen eine Anfrage über das Cloud Access Portal stellen und ihre Führungskraft als genehmigende Person angeben. Standard-Lesezugriffe werden innerhalb eines Werktags bereitgestellt.",
      es: "Todos los ingenieros que soliciten acceso a AWS RDS deben enviar una solicitud a través del Portal de Acceso a la Nube, indicando a su responsable como aprobador. Los roles de lectura estándar se aprovisionan en un día hábil.",
      fr: "Tous les ingénieurs demandant un accès AWS RDS doivent soumettre une demande via le portail d'accès au cloud, en désignant leur responsable comme approbateur. Les rôles de lecture standard sont provisionnés sous un jour ouvré.",
    },
    body: {
      en: "This policy defines the request, approval, and provisioning workflow for all cloud database access at Deutsche Bank. Requests are raised in the Cloud Access Portal. Read-only roles follow the standard one-day SLA; write and elevated roles are routed to Compliance for additional sign-off. Access is reviewed quarterly and revoked automatically on role change.",
    },
    comments: [
      { author: "M. Bauer", initials: "MB", when: "3 days ago", text: "Clear — the portal link in section 2 finally points to the new form." },
      { author: "L. García", initials: "LG", when: "1 week ago", text: "Would help to note the SLA for elevated roles here too." },
    ],
  },
  {
    id: "doc-2",
    source: "SharePoint",
    path: "Engineering › Onboarding",
    sourceLang: "de",
    visibility: "employee",
    rating: 4.2,
    reviews: 21,
    updated: "2026-07-19",
    title: {
      en: "RDS Onboarding Checklist",
      de: "RDS-Onboarding-Checkliste",
      es: "Lista de verificación de incorporación de RDS",
      fr: "Liste de contrôle d'intégration RDS",
    },
    snippet: {
      en: "Step-by-step checklist for new joiners requesting database access, including RDS read replicas, VPC peering approval, and credential rotation policy.",
      de: "Schritt-für-Schritt-Checkliste für neue Mitarbeitende, die Datenbankzugriff anfordern, einschließlich RDS-Read-Replicas, VPC-Peering-Genehmigung und Richtlinie zur Rotation von Zugangsdaten.",
      es: "Lista de verificación paso a paso para nuevos empleados que solicitan acceso a la base de datos, incluidas réplicas de lectura de RDS, aprobación de emparejamiento de VPC y política de rotación de credenciales.",
      fr: "Liste de contrôle étape par étape pour les nouveaux arrivants demandant un accès à la base de données, y compris les réplicas de lecture RDS, l'approbation du peering VPC et la politique de rotation des identifiants.",
    },
    body: {
      de: "Diese Checkliste führt neue Mitarbeitende durch die Beantragung des Datenbankzugriffs: Kontoerstellung, Zuweisung der Lese-Replica, Genehmigung des VPC-Peerings und Einrichtung der Rotation von Zugangsdaten. Jeder Schritt enthält den zuständigen Ansprechpartner.",
      en: "This checklist walks new joiners through requesting database access: account creation, read-replica assignment, VPC peering approval, and credential rotation setup. Each step lists the responsible contact.",
    },
    comments: [
      { author: "S. Devi", initials: "SD", when: "2 days ago", text: "The German original is fine but the translated VPC step reads a little oddly." },
    ],
  },
  {
    id: "doc-3",
    source: "SharePoint",
    path: "Compliance › IAM Standards",
    sourceLang: "en",
    visibility: "admin",
    rating: 4.9,
    reviews: 12,
    updated: "2026-07-16",
    title: {
      en: "DB-IAM-2026-07 — Elevated Access Standard",
      de: "DB-IAM-2026-07 — Standard für erweiterten Zugriff",
      es: "DB-IAM-2026-07 — Norma de acceso elevado",
      fr: "DB-IAM-2026-07 — Norme d'accès élevé",
    },
    snippet: {
      en: "Defines additional Compliance sign-off requirements for write-level or elevated AWS IAM roles, superseding section 4 of the 2025 access standard.",
      de: "Definiert zusätzliche Compliance-Freigabeanforderungen für Schreib- oder erweiterte AWS-IAM-Rollen und ersetzt Abschnitt 4 des Zugriffsstandards von 2025.",
      es: "Define requisitos adicionales de aprobación de Compliance para roles de IAM de AWS de escritura o elevados, sustituyendo la sección 4 de la norma de acceso de 2025.",
      fr: "Définit des exigences supplémentaires de validation de la Conformité pour les rôles IAM AWS d'écriture ou élevés, remplaçant la section 4 de la norme d'accès de 2025.",
    },
    body: {
      en: "Elevated and write-level IAM roles require Compliance sign-off in addition to line-manager approval. This standard defines the evidence required, the review window, and the automatic revocation triggers. Applies to all EU-region production accounts.",
    },
    comments: [],
  },
  {
    id: "doc-4",
    source: "Confluence",
    path: "RI Module › Infrastructure",
    sourceLang: "en",
    visibility: "employee",
    rating: 4.1,
    reviews: 9,
    updated: "2026-07-23",
    title: {
      en: "Reinsurance Module — Database Access Notes",
      de: "Rückversicherungsmodul — Hinweise zum Datenbankzugriff",
      es: "Módulo de reaseguro — Notas de acceso a la base de datos",
      fr: "Module de réassurance — Notes d'accès à la base de données",
    },
    snippet: {
      en: "Notes on database access patterns used by the RI reassignment service, including read-replica routing for SLA scoring queries.",
      de: "Hinweise zu Datenbankzugriffsmustern des RI-Neuzuweisungsdienstes, einschließlich Read-Replica-Routing für SLA-Bewertungsabfragen.",
      es: "Notas sobre los patrones de acceso a la base de datos utilizados por el servicio de reasignación de RI, incluido el enrutamiento de réplicas de lectura para las consultas de puntuación de SLA.",
      fr: "Notes sur les schémas d'accès à la base de données utilisés par le service de réaffectation RI, y compris le routage des réplicas de lecture pour les requêtes de scoring SLA.",
    },
    body: {
      en: "The RI reassignment service reads from a dedicated replica to keep SLA-scoring queries off the primary. This note documents the connection settings, the fallback path, and the metrics exported for the operations dashboard.",
    },
    comments: [
      { author: "R. Sharma", initials: "RS", when: "5 hours ago", text: "Updated the replica endpoint after the July migration." },
    ],
  },
  {
    id: "doc-5",
    source: "Jira",
    path: "Platform Ops › Access Requests",
    sourceLang: "en",
    visibility: "employee",
    rating: 3.8,
    reviews: 15,
    updated: "2026-07-20",
    title: {
      en: "TICKET-4471 — RDS access request template",
      de: "TICKET-4471 — Vorlage für RDS-Zugriffsanfrage",
      es: "TICKET-4471 — Plantilla de solicitud de acceso a RDS",
      fr: "TICKET-4471 — Modèle de demande d'accès RDS",
    },
    snippet: {
      en: "Reusable ticket template for RDS access requests. Auto-routes to the on-call DBA if unapproved after 24 hours and links to the Cloud Access Portal workflow.",
      de: "Wiederverwendbare Ticketvorlage für RDS-Zugriffsanfragen. Leitet nach 24 Stunden ohne Genehmigung automatisch an den Bereitschafts-DBA weiter und verlinkt auf den Cloud-Access-Portal-Workflow.",
      es: "Plantilla de ticket reutilizable para solicitudes de acceso a RDS. Se redirige automáticamente al DBA de guardia si no se aprueba tras 24 horas y enlaza con el flujo del Portal de Acceso a la Nube.",
      fr: "Modèle de ticket réutilisable pour les demandes d'accès RDS. Réachemine automatiquement vers le DBA d'astreinte si non approuvé après 24 heures et renvoie au workflow du portail d'accès au cloud.",
    },
    body: {
      en: "Use this template to raise an RDS access request. Fill in the environment, role level, and business justification. Unapproved tickets escalate to the on-call DBA after 24 hours.",
    },
    comments: [],
  },
];

/* ---------------- Admin: Overview dashboard ---------------- */
export const kpis = [
  { label: "Documents Indexed", value: "3,842", delta: "+126 this week", tone: "up" },
  { label: "Queries Today", value: "412", delta: "+8% vs yesterday", tone: "up" },
  { label: "Avg Response Time", value: "1.4s", delta: "-0.3s vs last week", tone: "up" },
  { label: "Active Users", value: "1,204", delta: "across EU regions", tone: "flat" },
];

export const queryTrend = [
  { day: "Mon", queries: 210 }, { day: "Tue", queries: 265 }, { day: "Wed", queries: 240 },
  { day: "Thu", queries: 310 }, { day: "Fri", queries: 295 }, { day: "Sat", queries: 98 }, { day: "Sun", queries: 74 },
];

export const topTopics = [
  { topic: "Onboarding", count: 142 }, { topic: "Expense Policy", count: 118 },
  { topic: "RI Module", count: 97 }, { topic: "AWS Access", count: 84 }, { topic: "Leave Policy", count: 61 },
];

export const langMix = [
  { name: "English", value: 1780, color: "#1656b8" },
  { name: "German", value: 1120, color: "#2684FF" },
  { name: "Spanish", value: 540, color: "#0E7A6B" },
  { name: "French", value: 402, color: "#9a6b00" },
];

export const knowledgeGaps = [
  "How to request a Jira project archive",
  "SharePoint access for contractors",
  "RI module rollback procedure",
];

/* ---------------- Admin: Access control matrix ---------------- */
export const accessMatrix = [
  { category: "Engineering Docs", employee: true, admin: true },
  { category: "HR Policies", employee: true, admin: true },
  { category: "Reinsurance Module Specs", employee: true, admin: true },
  { category: "Compliance Reports", employee: false, admin: true },
  { category: "IAM & Security Policies", employee: false, admin: true },
];

/* ---------------- Admin: Integrations ---------------- */
export const integrations = [
  { name: "Confluence", status: "Connected", docs: 1642, lastSync: "6 minutes ago", health: "green" },
  { name: "Jira", status: "Connected", docs: 981, lastSync: "22 minutes ago", health: "green" },
  { name: "SharePoint", status: "Sync delayed", docs: 1219, lastSync: "3 hours ago", health: "amber" },
];
