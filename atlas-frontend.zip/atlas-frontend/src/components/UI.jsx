import React from "react";
import { Star } from "lucide-react";
import { SOURCE_STYLE } from "../data/mock.js";

export function Chip({ children, tone = "muted" }) {
  return <span className={`chip chip-${tone}`}>{children}</span>;
}

export function VisibilityChip({ visibility }) {
  return visibility === "admin"
    ? <Chip tone="admin">Admin</Chip>
    : <Chip tone="employee">Employee</Chip>;
}

export function SourceLogo({ source, size = 22 }) {
  const st = SOURCE_STYLE[source] || { letter: "?", color: "#888" };
  return (
    <div
      style={{
        width: size, height: size, borderRadius: 6, flexShrink: 0,
        display: "flex", alignItems: "center", justifyContent: "center",
        background: `${st.color}22`, color: st.color,
        border: `1px solid ${st.color}55`,
        fontSize: size * 0.46, fontWeight: 800,
      }}
    >
      {st.letter}
    </div>
  );
}

export function Stars({ value, size = 13 }) {
  const full = Math.round(value);
  return (
    <span className="stars" title={`${value.toFixed(1)} / 5`}>
      {[0, 1, 2, 3, 4].map((i) => (
        <Star
          key={i}
          size={size}
          fill={i < full ? "currentColor" : "none"}
          strokeWidth={1.5}
          style={{ opacity: i < full ? 1 : 0.4 }}
        />
      ))}
    </span>
  );
}
