import React from "react";
import LanguageSelect from "./LanguageSelect.jsx";
import ThemeToggle from "./ThemeToggle.jsx";
import ProfileMenu from "./ProfileMenu.jsx";

export default function Header() {
  return (
    <header className="header">
      <div className="header-left">Deutsche Bank · ATLAS</div>
      <div className="header-right">
        <LanguageSelect />
        <ThemeToggle />
        <div style={{ width: 1, height: 24, background: "var(--border)" }} />
        <ProfileMenu />
      </div>
    </header>
  );
}
