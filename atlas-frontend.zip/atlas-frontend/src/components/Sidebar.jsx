import React from "react";
import { NavLink } from "react-router-dom";
import { Search, LayoutDashboard, Library, KeyRound, Plug } from "lucide-react";
import { useApp } from "../context/AppContext.jsx";

const NAV = [
  { to: "/search", label: "Search", icon: Search, roles: ["employee", "admin"] },
  { to: "/overview", label: "Overview", icon: LayoutDashboard, roles: ["admin"] },
  { to: "/library", label: "Document Library", icon: Library, roles: ["employee", "admin"] },
  { to: "/access", label: "Access Control", icon: KeyRound, roles: ["admin"] },
  { to: "/integrations", label: "Integrations", icon: Plug, roles: ["admin"] },
];

export default function Sidebar() {
  const { user } = useApp();
  const items = NAV.filter((n) => n.roles.includes(user.role));

  return (
    <aside className="sidebar">
      <div className="brand">
        <img src="/atlas-mark.svg" alt="ATLAS" className="brand-mark" />
        <div>
          <div className="brand-name">ATLAS</div>
          <div className="brand-tag">Navigate Knowledge.<br />Discover Insights.</div>
        </div>
      </div>

      <nav className="nav">
        {items.map((n) => {
          const Icon = n.icon;
          return (
            <NavLink
              key={n.to}
              to={n.to}
              className={({ isActive }) => `nav-item${isActive ? " active" : ""}`}
            >
              <Icon size={17} strokeWidth={1.85} />
              {n.label}
            </NavLink>
          );
        })}
      </nav>

      <div className="sidebar-foot">
        Deutsche Bank · Technology, Data and Innovation
      </div>
    </aside>
  );
}
