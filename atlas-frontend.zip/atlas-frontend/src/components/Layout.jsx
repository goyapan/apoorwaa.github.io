import React from "react";
import Sidebar from "./Sidebar.jsx";
import Header from "./Header.jsx";
import AnnouncementBanner from "./AnnouncementBanner.jsx";

export default function Layout({ children, wide }) {
  return (
    <div className="app-shell">
      <Sidebar />
      <div className="main-col">
        <Header />
        <AnnouncementBanner />
        <div className={`page${wide ? " page-wide" : ""}`}>{children}</div>
      </div>
    </div>
  );
}
