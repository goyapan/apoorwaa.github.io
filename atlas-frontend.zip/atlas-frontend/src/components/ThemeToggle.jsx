import React from "react";
import { Sun, Moon } from "lucide-react";
import { useApp } from "../context/AppContext.jsx";

export default function ThemeToggle() {
  const { theme, toggleTheme } = useApp();
  return (
    <button
      className="icon-btn"
      onClick={toggleTheme}
      title={theme === "light" ? "Switch to dark theme" : "Switch to light theme"}
      aria-label="Toggle theme"
    >
      {theme === "light" ? <Moon size={17} /> : <Sun size={17} />}
    </button>
  );
}
