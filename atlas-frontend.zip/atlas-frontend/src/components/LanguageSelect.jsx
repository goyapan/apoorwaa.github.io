import React, { useState, useRef, useEffect } from "react";
import { Globe, Check, ChevronDown } from "lucide-react";
import { useApp } from "../context/AppContext.jsx";
import { LANGUAGES } from "../data/mock.js";

export default function LanguageSelect() {
  const { language, setLanguage } = useApp();
  const [open, setOpen] = useState(false);
  const ref = useRef(null);
  const current = LANGUAGES.find((l) => l.code === language);

  useEffect(() => {
    const h = (e) => ref.current && !ref.current.contains(e.target) && setOpen(false);
    document.addEventListener("mousedown", h);
    return () => document.removeEventListener("mousedown", h);
  }, []);

  return (
    <div className="menu-wrap" ref={ref}>
      <button
        className="icon-btn"
        style={{ width: "auto", padding: "0 10px", gap: 6, display: "flex", alignItems: "center", fontSize: 12.5, color: "var(--text-muted)" }}
        onClick={() => setOpen((o) => !o)}
        title="Document display language"
      >
        <Globe size={16} />
        <span>{current?.code.toUpperCase()}</span>
        <ChevronDown size={13} />
      </button>
      {open && (
        <div className="menu" style={{ width: 190 }}>
          <div style={{ padding: "10px 14px", borderBottom: "1px solid var(--border)" }} className="label">
            Show documents in
          </div>
          {LANGUAGES.map((l) => (
            <button
              key={l.code}
              className="menu-item"
              onClick={() => { setLanguage(l.code); setOpen(false); }}
            >
              <span style={{ width: 18 }}>{l.flag}</span>
              <span style={{ flex: 1 }}>{l.label}</span>
              {language === l.code && <Check size={14} color="var(--accent)" />}
            </button>
          ))}
        </div>
      )}
    </div>
  );
}
