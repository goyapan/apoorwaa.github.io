import React, { useState } from "react";
import { X, Languages, MessageSquare, Send } from "lucide-react";
import { useApp } from "../context/AppContext.jsx";
import { SourceLogo, Stars, VisibilityChip } from "./UI.jsx";
import SpeakButton from "./SpeakButton.jsx";
import { langLabel } from "../data/mock.js";

/* Pick the best available translation, note if we fell back to source. */
function resolve(field, language, sourceLang) {
  if (field[language]) return { text: field[language], translated: language !== sourceLang };
  if (field[sourceLang]) return { text: field[sourceLang], translated: false };
  const first = Object.keys(field)[0];
  return { text: field[first], translated: true };
}

export default function DocumentModal({ doc, onClose }) {
  const { language } = useApp();
  const [comments, setComments] = useState(doc.comments || []);
  const [draft, setDraft] = useState("");

  const title = resolve(doc.title, language, doc.sourceLang);
  const body = resolve(doc.body, language, doc.sourceLang);

  const addComment = () => {
    if (!draft.trim()) return;
    setComments((c) => [{ author: "You", initials: "YO", when: "just now", text: draft.trim() }, ...c]);
    setDraft("");
  };

  return (
    <div
      onClick={onClose}
      style={{
        position: "fixed", inset: 0, zIndex: 60,
        background: "rgba(4, 12, 24, 0.55)", backdropFilter: "blur(2px)",
        display: "flex", justifyContent: "center", alignItems: "flex-start",
        padding: "56px 20px", overflowY: "auto",
      }}
    >
      <div
        className="fade-in"
        onClick={(e) => e.stopPropagation()}
        style={{
          width: "100%", maxWidth: 720, background: "var(--surface)",
          border: "1px solid var(--border)", borderRadius: "var(--radius)",
          boxShadow: "var(--shadow-lg)", overflow: "hidden",
        }}
      >
        {/* header */}
        <div style={{ display: "flex", alignItems: "flex-start", gap: 12, padding: "20px 22px", borderBottom: "1px solid var(--border)" }}>
          <SourceLogo source={doc.source} size={30} />
          <div style={{ flex: 1 }}>
            <div style={{ fontSize: 17, fontWeight: 700, letterSpacing: "-0.02em" }}>{title.text}</div>
            <div className="sub" style={{ marginTop: 3 }}>{doc.source} › {doc.path}</div>
          </div>
          <button className="icon-btn" onClick={onClose} aria-label="Close"><X size={18} /></button>
        </div>

        <div style={{ padding: 22 }}>
          {/* controls */}
          <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 16, flexWrap: "wrap" }}>
            <Stars value={doc.rating} />
            <span className="sub">{doc.rating.toFixed(1)} · {doc.reviews} reviews</span>
            <div style={{ flex: 1 }} />
            <SpeakButton text={`${title.text}. ${body.text}`} label="Listen" />
          </div>

          {title.translated && (
            <div style={{ display: "flex", alignItems: "center", gap: 7, fontSize: 12, color: "var(--text-muted)", marginBottom: 14 }}>
              <Languages size={14} color="var(--accent)" />
              Machine-translated to {langLabel(language)} · original in {langLabel(doc.sourceLang)}
            </div>
          )}

          {/* body */}
          <p style={{ fontSize: 14, lineHeight: 1.75, margin: "0 0 22px" }}>{body.text}</p>

          {/* metadata (at the end, as requested) */}
          <div className="panel-flat" style={{ padding: 16, marginBottom: 24 }}>
            <div className="label" style={{ marginBottom: 10 }}>Document details</div>
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", rowGap: 9, columnGap: 20, fontSize: 12.5 }}>
              <Meta k="Source" v={doc.source} />
              <Meta k="Location" v={doc.path} />
              <Meta k="Original language" v={langLabel(doc.sourceLang)} />
              <Meta k="Last updated" v={doc.updated} />
              <Meta k="Visibility" v={<VisibilityChip visibility={doc.visibility} />} />
              <Meta k="Rating" v={`${doc.rating.toFixed(1)} (${doc.reviews} reviews)`} />
            </div>
          </div>

          {/* comments */}
          <div className="label" style={{ display: "flex", alignItems: "center", gap: 6, marginBottom: 12 }}>
            <MessageSquare size={13} /> Comments ({comments.length})
          </div>

          <div style={{ display: "flex", gap: 10, marginBottom: 18 }}>
            <input
              className="input"
              placeholder="Add a comment…"
              value={draft}
              onChange={(e) => setDraft(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && addComment()}
            />
            <button className="btn btn-primary" onClick={addComment}><Send size={14} /> Post</button>
          </div>

          <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>
            {comments.length === 0 && <div className="sub">No comments yet. Be the first to add one.</div>}
            {comments.map((c, i) => (
              <div key={i} style={{ display: "flex", gap: 11 }}>
                <div className="avatar" style={{ width: 30, height: 30, fontSize: 11 }}>{c.initials}</div>
                <div>
                  <div style={{ fontSize: 12.5 }}>
                    <b>{c.author}</b> <span className="sub">· {c.when}</span>
                  </div>
                  <div style={{ fontSize: 13, marginTop: 2 }}>{c.text}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

function Meta({ k, v }) {
  return (
    <div style={{ display: "flex", justifyContent: "space-between", gap: 12 }}>
      <span className="sub">{k}</span>
      <span style={{ fontWeight: 500, textAlign: "right" }}>{v}</span>
    </div>
  );
}
