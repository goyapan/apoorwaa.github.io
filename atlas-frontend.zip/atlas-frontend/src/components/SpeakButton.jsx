import React, { useState, useEffect } from "react";
import { Volume2, Square } from "lucide-react";
import { useApp } from "../context/AppContext.jsx";

/*
  Text-to-speech using the browser's built-in SpeechSynthesis.
  No backend needed. Language is taken from the selected document
  display language so German text is read with a German voice when
  the OS provides one.
*/
const LOCALE = { en: "en-GB", de: "de-DE", es: "es-ES", fr: "fr-FR" };

export default function SpeakButton({ text, label = "Listen" }) {
  const { language } = useApp();
  const [speaking, setSpeaking] = useState(false);
  const supported = typeof window !== "undefined" && "speechSynthesis" in window;

  useEffect(() => () => supported && window.speechSynthesis.cancel(), [supported]);

  const toggle = () => {
    if (!supported) return;
    if (speaking) {
      window.speechSynthesis.cancel();
      setSpeaking(false);
      return;
    }
    const u = new SpeechSynthesisUtterance(text);
    u.lang = LOCALE[language] || "en-GB";
    u.onend = () => setSpeaking(false);
    u.onerror = () => setSpeaking(false);
    window.speechSynthesis.cancel();
    window.speechSynthesis.speak(u);
    setSpeaking(true);
  };

  if (!supported) return null;

  return (
    <button className="btn btn-ghost" style={{ padding: "7px 12px", fontSize: 12 }} onClick={toggle}>
      {speaking ? <Square size={13} /> : <Volume2 size={14} />}
      {speaking ? "Stop" : label}
    </button>
  );
}
