import React, { useState } from "react";
import { AlertTriangle, Info, X } from "lucide-react";
import { announcement } from "../data/mock.js";

const STYLES = {
  warning: { bg: "var(--warning-soft)", fg: "var(--warning)", Icon: AlertTriangle },
  info: { bg: "var(--accent-soft)", fg: "var(--accent)", Icon: Info },
  critical: { bg: "var(--danger-soft)", fg: "var(--danger)", Icon: AlertTriangle },
};

export default function AnnouncementBanner() {
  const [open, setOpen] = useState(true);
  if (!announcement.active || !open) return null;
  const s = STYLES[announcement.level] || STYLES.info;
  const Icon = s.Icon;

  return (
    <div
      className="fade-in"
      style={{
        display: "flex", alignItems: "center", gap: 10,
        background: s.bg, color: s.fg,
        padding: "10px 40px", fontSize: 12.5, fontWeight: 500,
        borderBottom: "1px solid var(--border)",
      }}
    >
      <Icon size={15} />
      <span style={{ flex: 1 }}>{announcement.message}</span>
      <button onClick={() => setOpen(false)} style={{ color: s.fg, display: "flex" }} aria-label="Dismiss">
        <X size={15} />
      </button>
    </div>
  );
}
