import React, { useState, useRef, useEffect } from "react";
import { MoreVertical, History, Download, Settings, LogOut } from "lucide-react";
import { useApp } from "../context/AppContext.jsx";

export default function ProfileMenu() {
  const { user, logout } = useApp();
  const [open, setOpen] = useState(false);
  const ref = useRef(null);

  useEffect(() => {
    const h = (e) => ref.current && !ref.current.contains(e.target) && setOpen(false);
    document.addEventListener("mousedown", h);
    return () => document.removeEventListener("mousedown", h);
  }, []);

  if (!user) return null;
  const roleLabel = user.role === "admin" ? "Admin" : "Employee";

  return (
    <div className="header-right" style={{ gap: 10 }}>
      <span className="sub">Viewing as</span>
      <span className="role-pill">{roleLabel}</span>

      <div className="avatar" title={user.name}>{user.initials}</div>
      <span style={{ fontSize: 13, fontWeight: 600 }}>{user.name}</span>

      <div className="menu-wrap" ref={ref}>
        <button className="icon-btn" onClick={() => setOpen((o) => !o)} aria-label="Account menu">
          <MoreVertical size={18} />
        </button>
        {open && (
          <div className="menu">
            <div className="menu-head">
              <div className="avatar">{user.initials}</div>
              <div>
                <div style={{ fontSize: 13, fontWeight: 600 }}>{user.name}</div>
                <div className="sub">{roleLabel}</div>
              </div>
            </div>
            <button className="menu-item"><History size={16} /> Search history</button>
            <button className="menu-item"><Download size={16} /> Downloads</button>
            <button className="menu-item"><Settings size={16} /> More settings</button>
            <div className="menu-sep" />
            <button className="menu-item" style={{ color: "var(--danger)" }} onClick={logout}>
              <LogOut size={16} /> Log out
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
