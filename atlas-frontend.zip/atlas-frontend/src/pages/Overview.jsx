import React from "react";
import { ArrowUpRight, ChevronRight } from "lucide-react";
import {
  LineChart, Line, BarChart, Bar, PieChart, Pie, Cell,
  XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
} from "recharts";
import { kpis, queryTrend, topTopics, langMix, knowledgeGaps } from "../data/mock.js";

const tip = { background: "var(--surface)", border: "1px solid var(--border)", borderRadius: 8, fontSize: 12, color: "var(--text)" };

export default function Overview() {
  return (
    <div>
      <div className="section-head">
        <div>
          <h1 className="h2">Overview</h1>
          <div className="sub" style={{ marginTop: 3 }}>Usage across EU regions · last refreshed 2 minutes ago</div>
        </div>
      </div>

      {/* KPIs */}
      <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 14, marginBottom: 18 }}>
        {kpis.map((k, i) => (
          <div className="panel" key={i}>
            <div className="label">{k.label}</div>
            <div style={{ fontSize: 26, fontWeight: 700, marginTop: 8, letterSpacing: "-0.02em" }}>{k.value}</div>
            <div style={{ fontSize: 11.5, marginTop: 5, display: "flex", alignItems: "center", gap: 3, color: k.tone === "up" ? "var(--success)" : "var(--text-muted)" }}>
              {k.tone === "up" && <ArrowUpRight size={12} />} {k.delta}
            </div>
          </div>
        ))}
      </div>

      {/* charts row */}
      <div style={{ display: "grid", gridTemplateColumns: "2fr 1fr", gap: 14, marginBottom: 18 }}>
        <div className="panel">
          <div className="label" style={{ marginBottom: 14 }}>Query volume — 7 days</div>
          <ResponsiveContainer width="100%" height={190}>
            <LineChart data={queryTrend}>
              <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" vertical={false} />
              <XAxis dataKey="day" tick={{ fontSize: 11, fill: "var(--text-muted)" }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fontSize: 11, fill: "var(--text-muted)" }} axisLine={false} tickLine={false} />
              <Tooltip contentStyle={tip} />
              <Line type="monotone" dataKey="queries" stroke="var(--accent)" strokeWidth={2.4} dot={false} />
            </LineChart>
          </ResponsiveContainer>
        </div>

        <div className="panel">
          <div className="label" style={{ marginBottom: 14 }}>Documents by language</div>
          <ResponsiveContainer width="100%" height={160}>
            <PieChart>
              <Pie data={langMix} dataKey="value" innerRadius={38} outerRadius={64} paddingAngle={3}>
                {langMix.map((e, i) => <Cell key={i} fill={e.color} stroke="none" />)}
              </Pie>
              <Tooltip contentStyle={tip} />
            </PieChart>
          </ResponsiveContainer>
          <div style={{ display: "flex", flexWrap: "wrap", gap: 10, justifyContent: "center", marginTop: 6 }}>
            {langMix.map((e, i) => (
              <span key={i} className="sub" style={{ fontSize: 11, display: "flex", alignItems: "center", gap: 5 }}>
                <span style={{ width: 8, height: 8, borderRadius: "50%", background: e.color }} /> {e.name}
              </span>
            ))}
          </div>
        </div>
      </div>

      {/* topics + gaps */}
      <div style={{ display: "grid", gridTemplateColumns: "2fr 1fr", gap: 14 }}>
        <div className="panel">
          <div className="label" style={{ marginBottom: 14 }}>Top searched topics</div>
          <ResponsiveContainer width="100%" height={180}>
            <BarChart data={topTopics} layout="vertical" margin={{ left: 20 }}>
              <XAxis type="number" hide />
              <YAxis dataKey="topic" type="category" tick={{ fontSize: 11.5, fill: "var(--text-muted)" }} axisLine={false} tickLine={false} width={95} />
              <Tooltip contentStyle={tip} />
              <Bar dataKey="count" fill="var(--accent)" radius={[0, 4, 4, 0]} barSize={13} />
            </BarChart>
          </ResponsiveContainer>
        </div>

        <div className="panel">
          <div className="label" style={{ marginBottom: 12 }}>Knowledge gaps</div>
          <div className="sub" style={{ fontSize: 12, marginBottom: 12 }}>Searched often, no strong result found.</div>
          {knowledgeGaps.map((g, i) => (
            <div key={i} style={{ display: "flex", alignItems: "center", gap: 7, fontSize: 13, padding: "8px 0", borderTop: i ? "1px solid var(--border)" : "none" }}>
              <ChevronRight size={13} color="var(--warning)" /> {g}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
