import React from "react";
import { Check, Lock, ShieldCheck } from "lucide-react";
import { accessMatrix } from "../data/mock.js";

function Cell({ allowed }) {
  return allowed ? (
    <span style={{ display: "flex", alignItems: "center", gap: 5, fontSize: 12.5, color: "var(--success)" }}>
      <Check size={14} /> Allowed
    </span>
  ) : (
    <span style={{ display: "flex", alignItems: "center", gap: 5, fontSize: 12.5, color: "var(--text-muted)" }}>
      <Lock size={12} /> Blocked
    </span>
  );
}

export default function AccessControl() {
  return (
    <div>
      <div className="section-head">
        <div>
          <h1 className="h2">Access Control</h1>
          <div className="sub" style={{ marginTop: 3 }}>Role-based document visibility by category.</div>
        </div>
      </div>

      <div className="panel-flat">
        <div style={{ display: "grid", gridTemplateColumns: "2fr 1fr 1fr", padding: "13px 20px", borderBottom: "1px solid var(--border)" }} className="label">
          <div>Category</div><div>Employee</div><div>Admin</div>
        </div>
        {accessMatrix.map((row, i) => (
          <div key={i} style={{ display: "grid", gridTemplateColumns: "2fr 1fr 1fr", alignItems: "center", padding: "15px 20px", borderBottom: "1px solid var(--border)", fontSize: 13.5 }}>
            <div style={{ fontWeight: 500 }}>{row.category}</div>
            <Cell allowed={row.employee} />
            <Cell allowed={row.admin} />
          </div>
        ))}
      </div>

      <div style={{ display: "flex", alignItems: "flex-start", gap: 9, marginTop: 16, padding: 14, borderRadius: "var(--radius)", background: "var(--surface)", border: "1px solid var(--border)", fontSize: 12.5, color: "var(--text-muted)" }}>
        <ShieldCheck size={15} color="var(--accent)" style={{ marginTop: 1 }} />
        Enforced at retrieval time — the search backend filters by role and document metadata before any result reaches the assistant, not only in the interface.
      </div>
    </div>
  );
}
