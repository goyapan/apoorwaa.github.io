import React, { useState } from "react";
import { FileText, Search as SearchIcon } from "lucide-react";
import { useApp } from "../context/AppContext.jsx";
import { SourceLogo, Stars, VisibilityChip } from "../components/UI.jsx";
import DocumentModal from "../components/DocumentModal.jsx";
import { documents, langLabel } from "../data/mock.js";

export default function Library() {
  const { user, language } = useApp();
  const [q, setQ] = useState("");
  const [openDoc, setOpenDoc] = useState(null);

  const visible = documents.filter((d) => user.role === "admin" || d.visibility === "employee");
  const filtered = visible.filter((d) => {
    const t = (d.title[language] || d.title.en).toLowerCase();
    return t.includes(q.toLowerCase());
  });

  return (
    <div>
      <div className="section-head">
        <div>
          <h1 className="h2">Document Library</h1>
          <div className="sub" style={{ marginTop: 3 }}>
            {user.role === "admin"
              ? "All indexed documents across connected sources."
              : "Documents available to you. Admin-only documents are hidden."}
          </div>
        </div>
        <div style={{ display: "flex", alignItems: "center", gap: 8, background: "var(--surface)", border: "1px solid var(--border-strong)", borderRadius: 999, padding: "6px 14px", width: 260 }}>
          <SearchIcon size={15} color="var(--text-muted)" />
          <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Filter documents…" style={{ border: "none", outline: "none", background: "transparent", fontSize: 13, width: "100%", color: "var(--text)" }} />
        </div>
      </div>

      <div className="panel-flat">
        <div style={{ display: "grid", gridTemplateColumns: "2.4fr 1.2fr 1fr 1.1fr 0.9fr", padding: "12px 18px", borderBottom: "1px solid var(--border)" }} className="label">
          <div>Title</div><div>Source</div><div>Language</div><div>Rating</div><div>Visibility</div>
        </div>
        {filtered.map((d) => {
          const t = d.title[language] || d.title[d.sourceLang] || d.title.en;
          return (
            <div
              key={d.id}
              onClick={() => setOpenDoc(d)}
              style={{ display: "grid", gridTemplateColumns: "2.4fr 1.2fr 1fr 1.1fr 0.9fr", alignItems: "center", padding: "13px 18px", borderBottom: "1px solid var(--border)", cursor: "pointer", fontSize: 13.5 }}
            >
              <div style={{ display: "flex", alignItems: "center", gap: 9, paddingRight: 12 }}>
                <FileText size={15} color="var(--text-muted)" />
                <span style={{ fontWeight: 500 }}>{t}</span>
              </div>
              <div style={{ display: "flex", alignItems: "center", gap: 7 }}>
                <SourceLogo source={d.source} size={18} />
                <span className="sub">{d.source}</span>
              </div>
              <div className="sub">{langLabel(d.sourceLang)}</div>
              <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
                <Stars value={d.rating} size={12} />
                <span className="sub" style={{ fontSize: 12 }}>{d.rating.toFixed(1)}</span>
              </div>
              <div><VisibilityChip visibility={d.visibility} /></div>
            </div>
          );
        })}
        {filtered.length === 0 && (
          <div style={{ padding: 30, textAlign: "center" }} className="sub">No documents match “{q}”.</div>
        )}
      </div>

      {openDoc && <DocumentModal doc={openDoc} onClose={() => setOpenDoc(null)} />}
    </div>
  );
}
