import React, { useState, useRef } from "react";
import { Search as SearchIcon, Mic, Sparkles, Languages, MessageSquare } from "lucide-react";
import { useApp } from "../context/AppContext.jsx";
import { SourceLogo, Stars, VisibilityChip } from "../components/UI.jsx";
import SpeakButton from "../components/SpeakButton.jsx";
import DocumentModal from "../components/DocumentModal.jsx";
import { aiSummary, documents, langLabel, LANGUAGES } from "../data/mock.js";

const SOURCES = ["All", "Confluence", "Jira", "SharePoint"];

export default function Search() {
  const { user, language } = useApp();
  const [query, setQuery] = useState(aiSummary.query);
  const [submitted, setSubmitted] = useState(true); // pre-populated for demo
  const [filter, setFilter] = useState("All");
  const [openDoc, setOpenDoc] = useState(null);
  const [listening, setListening] = useState(false);
  const recogRef = useRef(null);

  // documents this user is allowed to see
  const visible = documents.filter((d) => user.role === "admin" || d.visibility === "employee");
  const results = filter === "All" ? visible : visible.filter((d) => d.source === filter);

  const summaryText = aiSummary.text[language] || aiSummary.text.en;

  const runSearch = () => query.trim() && setSubmitted(true);

  // Voice search via the browser SpeechRecognition API (no backend).
  const voiceSearch = () => {
    const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SR) { alert("Voice search isn't supported in this browser. Try Chrome."); return; }
    const r = new SR();
    r.lang = { en: "en-GB", de: "de-DE", es: "es-ES", fr: "fr-FR" }[language] || "en-GB";
    r.onstart = () => setListening(true);
    r.onend = () => setListening(false);
    r.onresult = (e) => { setQuery(e.results[0][0].transcript); setSubmitted(true); };
    recogRef.current = r;
    r.start();
  };

  return (
    <div style={{ maxWidth: 860, margin: "0 auto" }}>
      {/* Hero */}
      <div style={{ textAlign: "center", paddingTop: 8, paddingBottom: 22 }}>
        <div style={{ display: "flex", alignItems: "center", justifyContent: "center", gap: 11, marginBottom: 6 }}>
          <img src="/atlas-mark.svg" alt="" style={{ width: 34, height: 34 }} />
          <span style={{ fontSize: 26, fontWeight: 700, letterSpacing: "-0.03em" }}>ATLAS</span>
        </div>
        <div className="sub" style={{ fontSize: 13 }}>Navigate Knowledge. Discover Insights.</div>
      </div>

      {/* Search bar */}
      <div
        style={{
          display: "flex", alignItems: "center", gap: 12,
          background: "var(--surface)", border: "1px solid var(--border-strong)",
          borderRadius: 999, padding: "6px 8px 6px 18px", boxShadow: "var(--shadow)",
          maxWidth: 640, margin: "0 auto",
        }}
      >
        <SearchIcon size={17} color="var(--text-muted)" />
        <input
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && runSearch()}
          placeholder="Search across Confluence, Jira and SharePoint…"
          style={{ flex: 1, border: "none", outline: "none", background: "transparent", fontSize: 14.5, color: "var(--text)" }}
        />
        <button
          className="icon-btn"
          onClick={voiceSearch}
          title="Voice search"
          style={{ color: listening ? "var(--danger)" : "var(--text-muted)" }}
        >
          <Mic size={18} />
        </button>
        <button className="btn btn-primary" style={{ borderRadius: 999, padding: "8px 18px" }} onClick={runSearch}>
          Search
        </button>
      </div>

      {/* source logos */}
      <div style={{ display: "flex", alignItems: "center", justifyContent: "center", gap: 8, marginTop: 16 }}>
        <span className="sub" style={{ fontSize: 11.5 }}>Searching across</span>
        {["Confluence", "Jira", "SharePoint"].map((s) => (
          <span key={s} style={{ display: "inline-flex", alignItems: "center", gap: 6, padding: "3px 10px 3px 4px", border: "1px solid var(--border)", borderRadius: 999, background: "var(--surface)" }}>
            <SourceLogo source={s} size={16} />
            <span className="sub" style={{ fontSize: 11.5 }}>{s}</span>
          </span>
        ))}
      </div>

      {submitted && (
        <>
          {/* Filter tabs */}
          <div style={{ display: "flex", alignItems: "center", gap: 4, marginTop: 30, borderBottom: "1px solid var(--border)" }}>
            {SOURCES.map((s) => (
              <button
                key={s}
                onClick={() => setFilter(s)}
                style={{
                  fontSize: 12.5, fontWeight: 600, padding: "10px 14px", marginBottom: -1,
                  color: filter === s ? "var(--accent)" : "var(--text-muted)",
                  borderBottom: `2px solid ${filter === s ? "var(--accent)" : "transparent"}`,
                }}
              >
                {s}
              </button>
            ))}
            <div style={{ marginLeft: "auto", display: "flex", alignItems: "center", gap: 6 }} className="sub">
              <Languages size={13} /> Results shown in {langLabel(language)}
            </div>
          </div>

          {/* AI summary */}
          <div className="panel fade-in" style={{ marginTop: 22, borderColor: "color-mix(in srgb, var(--accent) 35%, var(--border))" }}>
            <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 12 }}>
              <Sparkles size={15} color="var(--accent)" />
              <span className="label" style={{ color: "var(--accent)" }}>AI Summary</span>
              <div style={{ marginLeft: "auto" }}>
                <SpeakButton text={summaryText} label="Listen" />
              </div>
            </div>
            <p style={{ fontSize: 14.5, lineHeight: 1.7, margin: 0 }}>{summaryText}</p>
            <div style={{ display: "flex", gap: 8, marginTop: 16, flexWrap: "wrap" }}>
              {aiSummary.citations
                .filter((c) => user.role === "admin" || c.visibility !== "admin")
                .map((c) => (
                  <span key={c.n} style={{ display: "inline-flex", alignItems: "center", gap: 6, fontSize: 11.5, padding: "4px 9px", border: "1px solid var(--border)", borderRadius: 7, background: "var(--surface-2)" }}>
                    <span style={{ width: 15, height: 15, borderRadius: 4, background: "var(--accent-soft)", color: "var(--accent)", display: "inline-flex", alignItems: "center", justifyContent: "center", fontSize: 9.5, fontWeight: 700 }}>{c.n}</span>
                    {c.title}
                  </span>
                ))}
            </div>
            <div className="sub" style={{ marginTop: 12, fontSize: 11.5 }}>Confidence {aiSummary.confidence}% · grounded in cited sources</div>
          </div>

          {/* Results feed */}
          <div className="label" style={{ margin: "28px 0 14px" }}>Relevant documents</div>
          <div style={{ display: "flex", flexDirection: "column", gap: 18 }}>
            {results.map((d) => {
              const t = d.title[language] || d.title[d.sourceLang] || d.title.en;
              const sn = d.snippet[language] || d.snippet[d.sourceLang] || d.snippet.en;
              const translated = !d.title[language] || language !== d.sourceLang;
              return (
                <div
                  key={d.id}
                  onClick={() => setOpenDoc(d)}
                  style={{ cursor: "pointer", paddingBottom: 18, borderBottom: "1px solid var(--border)" }}
                >
                  <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 6 }}>
                    <SourceLogo source={d.source} size={20} />
                    <span className="sub" style={{ fontSize: 12 }}>{d.source} › {d.path}</span>
                  </div>
                  <div style={{ fontSize: 15.5, fontWeight: 600, color: "var(--accent)", marginBottom: 5 }}>{t}</div>
                  <p style={{ fontSize: 13, lineHeight: 1.6, color: "var(--text-muted)", margin: "0 0 9px" }}>{sn}</p>
                  <div style={{ display: "flex", alignItems: "center", gap: 12, flexWrap: "wrap" }}>
                    <span style={{ display: "flex", alignItems: "center", gap: 6 }}>
                      <Stars value={d.rating} />
                      <span className="sub" style={{ fontSize: 12 }}>{d.rating.toFixed(1)} · {d.reviews} reviews</span>
                    </span>
                    <span className="sub" style={{ fontSize: 12, display: "flex", alignItems: "center", gap: 4 }}>
                      <MessageSquare size={12} /> {d.comments.length}
                    </span>
                    {translated && (
                      <span className="sub" style={{ fontSize: 11.5, display: "flex", alignItems: "center", gap: 4 }}>
                        <Languages size={12} /> translated from {langLabel(d.sourceLang)}
                      </span>
                    )}
                    <VisibilityChip visibility={d.visibility} />
                  </div>
                </div>
              );
            })}
          </div>
        </>
      )}

      {openDoc && <DocumentModal doc={openDoc} onClose={() => setOpenDoc(null)} />}
    </div>
  );
}
