import React, { useState } from "react";
import { useApp } from "../context/AppContext.jsx";
import { LogIn, Compass } from "lucide-react";

export default function Login() {
  const { login } = useApp();
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");

  const submit = () => {
    if (!username.trim() || !password.trim()) return;
    login(username.trim());
  };

  return (
    <div style={{ display: "flex", minHeight: "100vh" }}>
      {/* Brand panel */}
      <div
        style={{
          flex: "1 1 46%", background: "linear-gradient(150deg, #0a2540 0%, #123a63 60%, #1656b8 130%)",
          color: "#fff", padding: "56px 60px", display: "flex", flexDirection: "column", justifyContent: "space-between",
          position: "relative", overflow: "hidden",
        }}
      >
        <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
          <img src="/atlas-mark.svg" alt="ATLAS" style={{ width: 40, height: 40 }} />
          <span style={{ fontSize: 18, fontWeight: 700, letterSpacing: "-0.02em" }}>ATLAS</span>
        </div>

        <div style={{ maxWidth: 420 }}>
          <div style={{ fontSize: 13, letterSpacing: "0.14em", textTransform: "uppercase", color: "#8fbcf5", marginBottom: 18 }}>
            Deutsche Bank · Technology, Data and Innovation
          </div>
          <h1 style={{ fontSize: 38, lineHeight: 1.15, fontWeight: 700, letterSpacing: "-0.03em", margin: 0 }}>
            The atlas of everything Deutsche Bank knows.
          </h1>
          <p style={{ fontSize: 15, lineHeight: 1.6, color: "#cfe0f5", marginTop: 18 }}>
            One place to search across Confluence, Jira and SharePoint — in your language,
            grounded in cited sources you can trust.
          </p>
          <div style={{ display: "flex", alignItems: "center", gap: 9, marginTop: 26, fontSize: 14, color: "#9fc3f0" }}>
            <Compass size={17} /> Navigate Knowledge. Discover Insights.
          </div>
        </div>

        <div style={{ fontSize: 11.5, color: "#7ea6da" }}>For internal use only · © 2026 Deutsche Bank AG</div>

        {/* faint compass rings */}
        <div style={{ position: "absolute", right: -120, bottom: -120, width: 360, height: 360, border: "1px solid rgba(255,255,255,0.08)", borderRadius: "50%" }} />
        <div style={{ position: "absolute", right: -60, bottom: -60, width: 240, height: 240, border: "1px solid rgba(255,255,255,0.08)", borderRadius: "50%" }} />
      </div>

      {/* Form panel */}
      <div style={{ flex: "1 1 54%", display: "flex", alignItems: "center", justifyContent: "center", padding: 40, background: "var(--bg)" }}>
        <div style={{ width: "100%", maxWidth: 360 }}>
          <h2 style={{ fontSize: 24, fontWeight: 700, letterSpacing: "-0.02em", margin: 0 }}>Sign in</h2>
          <p className="sub" style={{ marginTop: 6, marginBottom: 28 }}>Use your Deutsche Bank credentials to continue.</p>

          <label className="label">Username</label>
          <input
            className="input"
            style={{ margin: "7px 0 18px" }}
            placeholder="e.g. rohit.sharma"
            value={username}
            onChange={(e) => setUsername(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && submit()}
            autoFocus
          />

          <label className="label">Password</label>
          <input
            className="input"
            style={{ margin: "7px 0 24px" }}
            type="password"
            placeholder="••••••••"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && submit()}
          />

          <button className="btn btn-primary" style={{ width: "100%", padding: "12px" }} onClick={submit}>
            <LogIn size={16} /> Sign in
          </button>

          <p className="sub" style={{ marginTop: 18, lineHeight: 1.6 }}>
            Demo tip: any password works. Sign in with a username containing
            <b> “admin”</b> to see the admin view, or anything else for the employee view.
          </p>
        </div>
      </div>
    </div>
  );
}
