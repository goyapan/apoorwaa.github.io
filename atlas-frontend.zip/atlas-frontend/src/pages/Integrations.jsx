import React from "react";
import { RefreshCw, Plus } from "lucide-react";
import { SourceLogo, Chip } from "../components/UI.jsx";
import { integrations } from "../data/mock.js";

export default function Integrations() {
  return (
    <div>
      <div className="section-head">
        <div>
          <h1 className="h2">Integrations</h1>
          <div className="sub" style={{ marginTop: 3 }}>Connected knowledge sources feeding the index.</div>
        </div>
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 16 }}>
        {integrations.map((it, i) => (
          <div className="panel" key={i}>
            <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 16 }}>
              <div style={{ display: "flex", alignItems: "center", gap: 9 }}>
                <SourceLogo source={it.name} size={26} />
                <span style={{ fontSize: 14.5, fontWeight: 700 }}>{it.name}</span>
              </div>
              <Chip tone={it.health === "green" ? "green" : "amber"}>{it.status}</Chip>
            </div>
            <div style={{ display: "flex", flexDirection: "column", gap: 8, fontSize: 12.5, color: "var(--text-muted)" }}>
              <div style={{ display: "flex", justifyContent: "space-between" }}>
                <span>Documents synced</span><span style={{ color: "var(--text)", fontWeight: 600 }}>{it.docs.toLocaleString()}</span>
              </div>
              <div style={{ display: "flex", justifyContent: "space-between" }}>
                <span>Last sync</span><span style={{ color: "var(--text)", fontWeight: 600 }}>{it.lastSync}</span>
              </div>
            </div>
            <button className="btn btn-ghost" style={{ width: "100%", marginTop: 16, fontSize: 12.5 }}>
              <RefreshCw size={13} /> Sync now
            </button>
          </div>
        ))}

        <div className="panel" style={{ display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", border: "1px dashed var(--border-strong)", background: "transparent", color: "var(--text-muted)" }}>
          <Plus size={20} style={{ marginBottom: 8 }} />
          <div style={{ fontSize: 13 }}>Add a source</div>
        </div>
      </div>
    </div>
  );
}
